export {default as Navbar} from './Navbar';
export {default as Homepage} from './Homepage.jsx'
export {default as Cryptocurrencies} from './Cryptocurrencies.jsx'
export {default as CryptoDetails} from './Cryptodetails.jsx'
export {default as Exachanges} from './Exchanges.jsx'
export {default as News} from './News.jsx'