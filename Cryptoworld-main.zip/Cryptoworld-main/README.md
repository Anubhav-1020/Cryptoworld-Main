Demo here 
https://cryptoworld12.netlify.app/


https://user-images.githubusercontent.com/56160725/163726849-ad318caf-657b-4c06-b9b3-b2abe15701fa.mp4

